# Node-sample-app

### install 

`npm install`

### build client

`npm run-script build`

### run

`node server.js`

### check

`http://localhost:8080/`
